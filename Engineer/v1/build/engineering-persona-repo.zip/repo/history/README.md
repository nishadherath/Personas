# History

Superseded versions kept for reference. Not loaded by any agent.

- v0_original.md: the TypeScript/Node.js-scoped persona as uploaded.
- v1_single_file_multilanguage.md: first rewrite, one file, 15 languages, before model-class adaptation.
- v2 (single file with model-class tags and loading matrix) was not preserved as a standalone file; its content became source/core.source.md and source/languages.source.md.
